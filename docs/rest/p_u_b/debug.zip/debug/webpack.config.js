
function __out(_t,_obj){
  console.log('>>> '+_t+' >>>')
  console.log(_obj)
  console.log( '<<< '+_t+' <<<')
}
const path = require('path') 
//__out('global',global)
// __out('module',module)
// const vscode = require('vscode')
// __out('vscode',vscode)
// __out('require',require.main)
// __out('env',process.env)

// const node_modules_dir = path.resolve(process.argv.slice(1)[0], '../../../')
// const npd = process.env.NODE_MODULES_EX || ''
const npd = "D:/sites/GitHub/osbb-gr-44/webpack/node_modules/"

var requireEx = _p => require(path.resolve(npd, _p))

const { CleanWebpackPlugin } = requireEx('clean-webpack-plugin')

const TerserPlugin = requireEx('terser-webpack-plugin')
const OptimizeCssAssetsPlugin = requireEx('optimize-css-assets-webpack-plugin')
const WebpackObfuscator = requireEx('webpack-obfuscator')

process.on('warning', warning =>__out('Warning',warning))

// __out('process.cwd',process.cwd())
// __out('process',process)

module.exports = (env, argv) => {
  var isDev = 0

  // __out(' _output', _output)

  return {


    entry:     {
      'exo-it__fb_log': path.resolve(__dirname, 'src/exo-it__fb_log.js')
    },
    output: {
      path: path.resolve(__dirname, './'),
    },

    module: {
      rules: [
        {
          test: /\.js$/,
          exclude: /(node_modules|bower_components)/,
          use: {
            loader: path.join(npd, 'babel-loader'),
            options: {
              presets: [path.join(npd, '@babel/preset-env')]
            }
          }
        }
      ]
    },
    plugins: [
      new CleanWebpackPlugin({
        cleanOnceBeforeBuildPatterns: ['**/*', '!src/**', '!**/webpack.config.js', '!**/package.json'],
        cleanAfterEveryBuildPatterns: ['!src/**', '!**/webpack.config.js', '!**/package.json']
      }),
      new (requireEx('webpackbar'))({})
    ]
    ,
    optimization: {
      minimize: !isDev,
      minimizer:
        (!isDev && [
          new TerserPlugin({
            terserOptions: {
              output: {
                comments: false
              }
            },
            extractComments: false
          }),
          new OptimizeCssAssetsPlugin({
            //  assetNameRegExp: /\.dist\.css$/g,
            cssProcessor: requireEx('cssnano'),
            cssProcessorPluginOptions: {
              preset: ['default', { discardComments: { removeAll: true } }]
            },
            canPrint: false
          }),
          new WebpackObfuscator(
            {
              rotateStringArray: true
            },
            ['excluded_bundle_name.js']
          )
        ]) ||
        []
    }
  }
}
