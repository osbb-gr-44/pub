var addScriptNext = (src_url, cb) => {
  if (cb()) {
    return Promise.resolve()
  } else {
    return new Promise((resolve, reject) => {
      ;((src_url, cb) => {
        var _opt = 0

        if (typeof src_url === 'object') {
          _opt = src_url
          src_url = _opt.url
        }

        if (
          ![].slice
            .call(document.querySelectorAll('script[src]'))
            .find(_ => _.getAttribute('src') === src_url)
        ) {
          var script = document.createElement('script')

          if (_opt && _opt.attr) {
            Object.keys(_opt.attr).map(_ => {
              script.setAttribute(_, _opt.attr[_])
            })
          }
          script.src = src_url
          script.type = 'text/javascript' // no need for HTML5
          cb(script)
          document.getElementsByTagName('body')[0].appendChild(script) // for IE6
        }
      })(src_url, function (script) {
        function _next () {
          setTimeout(function () {
            if (!cb()) {
              _next()
            } else {
              resolve(script)
            }
          }, 300)
        }
        _next()
      })
    })
  }
}

window.initFirebaseDb = function (_opt,_cb) {
  addScriptNext(
    'https://www.gstatic.com/firebasejs/3.6.9/firebase.js',
    () => window.firebase
  ).then(_script => {
    firebase.initializeApp({
      apiKey: 'AIzaSyA7XK_xLY-EPZ5nwcHsVpdaZwIgNyiZBMQ',
      authDomain: 'exo-it.firebaseapp.com',
      databaseURL: 'https://exo-it.firebaseio.com',
      storageBucket: 'exo-it.appspot.com',
      messagingSenderId: '498521469323'
    })
    var database = firebase.database()
    _conn = {}
    _conn.db = database
    _conn.del = () =>
      firebase
        .database()
        .ref(_opt.idx)
        .remove()

    _conn.val = () =>
      firebase
        .database()
        .ref(_opt.idx)
        .once('value')
        .then(snapshot => snapshot.val())

    _conn.send = _d =>
    {
      var _id=_d.id||Date.now()
      if(_d.id)
      {
        delete _d.id
      }
      firebase
        .database()
        .ref(_opt.idx + '/' + _id)
        .set(_d)
    }
    // Reference to the /messages/ database path.

    var messagesRef = _opt.orderRef
      ? database.ref(_opt.idx).orderByChild(_opt.orderRef)
      : database.ref(_opt.idx)

    var receiveFn = 0

    Object.defineProperty(_conn, 'receive', {
      set: function (v) {
        // Make sure we remove all previous listeners.
        messagesRef.off()
        if (v) {
          receiveFn = v
          var setMessage = function (data) {
            if(receiveFn&& typeof receiveFn==="function")
            {
              receiveFn('on setMessage', data.key, data.val())
            }
          }
          messagesRef.limitToLast(20).on('child_added', setMessage)
          messagesRef.limitToLast(20).on('child_changed', setMessage)
        } else {
          receiveFn = 0
        }
      },
      get: function () {
        return receiveFn
      }
    })
    return  _conn
  })
  return _opt
}
