require('D:/sites/GitHub/osbb-gr-44/webpack/helpers/support.js')
_G.out.lChalk=_G.out.lChalk.bold.hex('#00B8B1')
_G.out.rChalk=_G.out.lChalk
var _argv=process.argv.slice(2)

if(_argv.includes('--task=build'))
{
    const pkgPath = require.resolve(`${_G.npdr}webpack-cli/package.json`);
    const pkg = require(pkgPath);
    _G.out(pkg.name,'pkg')
    /*require(path.resolve(
        path.dirname(pkgPath),
        pkg.bin[installedClis[0].binName]
      ));*/
}