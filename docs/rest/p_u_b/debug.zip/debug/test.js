
require('D:/sites/GitHub/osbb-gr-44/webpack/helpers/support.js')

//_G.out.tpl("_______ %s _______>","<______ %s _______")
_G.out.lChalk=_G.out.lChalk.bold.hex('#00B8B1')
_G.out.rChalk=_G.out.lChalk
 //_G.out('%WEBPACK__NODE_MODULES%',path.resolve(process.env.WEBPACK__NODE_MODULES))
 // _G.out(path.resolve(process.env.WEBPACK__NODE_MODULES))
 // _G.out(path.resolve(_G.npdr),'_G.npdr')
 //_G.out(path,'path')





 const pkgPath = require.resolve(`${_G.npdr}webpack-cli/package.json`);
 const pkg = require(pkgPath);
 
 _G.out(pkg,'pkg')

 /*const path = require("path");
 require(path.resolve(
   path.dirname(pkgPath),
   pkg.bin[installedClis[0].binName]
 ));
*/
 // _G.cmd()
  /*
  node test.js
 echo %PATHEXT%
 echo %WEBPACK__NODE_MODULES%
  */